﻿Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Net.Mail

Public Class Form1

    Private WithEvents TrayIcon As New NotifyIcon()
    Private WithEvents DailyCheckTimer As New Timer()

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        TrayIcon.Visible = True

        ' Configure the Timer
        SaveTimer.Interval = 100 ' Debounce
        AddHandler SaveTimer.Tick, AddressOf SaveTimer_Tick
        LoadNotesForDate(Today)

        ' Add right-click menu to RichTextBox
        RichTextBox1.ContextMenuStrip = CreateRichTextBoxContextMenu()

        ' Set the icon for the NotifyIcon
        TrayIcon.Icon = Me.Icon

        ' Add a context menu to the NotifyIcon
        Dim contextMenu As New ContextMenuStrip()
        contextMenu.Items.Add("Exit", Nothing, AddressOf ExitToolStripMenuItem_Click)
        TrayIcon.ContextMenuStrip = contextMenu

        Dim textBoxContextMenu As New ContextMenuStrip()

        ' Get the working area of the screen
        Dim workingArea As Rectangle = Screen.PrimaryScreen.WorkingArea

        ' Set the form position
        Me.Location = New Point(workingArea.Right - Me.Width - 15, workingArea.Bottom - Me.Height - 15)

        UpdateBoldedDatesForMonth(DateTime.Now)

        ' Calculate the time remaining until 8 AM
        Dim now As DateTime = DateTime.Now
        Dim next8AM As DateTime = If(now.Hour >= 8, now.Date.AddDays(1).AddHours(8), now.Date.AddHours(8))
        Dim timeRemaining As TimeSpan = next8AM - now

        ' Configure the timer interval to trigger at 8 AM daily
        DailyCheckTimer.Interval = timeRemaining.TotalMilliseconds

        ' Start the timer
        DailyCheckTimer.Start()

        ' Load settings
        Dim alertsSetting As String = My.Settings.Alerts

        ' Update UI based on loaded settings
        Select Case alertsSetting
            Case "On"
                If My.Settings.Server = "smtp.gmail.com" Then
                    gmailSubMenuItem.Checked = True
                Else
                    outlookSubMenuItem.Checked = True
                End If
                disableSubMenuItem.Checked = False
            Case "Off"
                gmailSubMenuItem.Checked = False
                outlookSubMenuItem.Checked = False
                disableSubMenuItem.Checked = True
        End Select

    End Sub

    Private Sub DailyCheckTimer_Tick(sender As Object, e As EventArgs) Handles DailyCheckTimer.Tick
        ' Perform the daily check at 8 AM
        PerformDailyCheck()
    End Sub

    Private Sub PerformDailyCheck()
        ' Check if there is an RTF file associated with the current date
        Dim rtfFilePath As String = GetFilePath(DateTime.Today)
        If File.Exists(rtfFilePath) Then
            ' Execute the SendEmail routine
            SendEmail()
        End If
    End Sub

    Private Sub RichTextBox1_LinkClicked(sender As Object, e As LinkClickedEventArgs) Handles RichTextBox1.LinkClicked
        Dim url = e.LinkText
        If Not String.IsNullOrEmpty(url) Then
            Try
                Dim psi As New ProcessStartInfo With {
                .FileName = url,
                .UseShellExecute = True
            }
                Process.Start(psi)
            Catch ex As Exception
                MessageBox.Show($"Failed to open URL: {ex.Message}")
            End Try
        End If
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged
        ' Restart the Timer on text change to wait 
        SaveTimer.Stop() ' Stop the Timer to reset the interval
        SaveTimer.Start() ' Start (or restart) the Timer

        RemoveHandler RichTextBox1.TextChanged, AddressOf RichTextBox1_TextChanged

        Try
            Dim words As New Dictionary(Of String, (String, FontStyle)) From {
            {"bday", ("Birthday", FontStyle.Underline)},
            {"mtg", ("Meeting", FontStyle.Underline)}
        }

            ' Detect if the last typed word is one of the specified abbreviations
            Dim currentText As String = RichTextBox1.Text
            Dim caretPosition As Integer = RichTextBox1.SelectionStart
            Dim wordStart As Integer = currentText.LastIndexOf(" "c, Math.Max(0, caretPosition - 2)) + 1
            Dim wordEnd As Integer = caretPosition
            Dim wordLength As Integer = wordEnd - wordStart
            If wordLength <= 0 Then Return
            Dim word As String = currentText.Substring(wordStart, wordLength).Trim()

            If words.ContainsKey(word) Then
                ' Replace the abbreviation with the full word and apply formatting
                With RichTextBox1
                    .Select(wordStart, wordLength)
                    Dim replacement = words(word)
                    .SelectedText = replacement.Item1 + " "
                    .Select(wordStart, replacement.Item1.Length)
                    .SelectionFont = New Font(.SelectionFont, replacement.Item2)
                    ' Adjust the caret position
                    .SelectionStart = wordStart + replacement.Item1.Length + 1
                    .SelectionLength = 0
                End With
            End If
        Finally
            ' Reattach the handler
            AddHandler RichTextBox1.TextChanged, AddressOf RichTextBox1_TextChanged
        End Try

    End Sub
    Private Sub Form1_Click(sender As Object, e As EventArgs) Handles MyBase.Click
        UpdateBoldedDatesForMonth(DateTime.Today)
    End Sub
    Private Sub RichTextBox1_Click(sender As Object, e As EventArgs) Handles RichTextBox1.Click
        UpdateBoldedDatesForMonth(DateTime.Today)
    End Sub
    Private Sub MonthCalendar1_Click(sender As Object, e As EventArgs) Handles MonthCalendar1.Click
        UpdateBoldedDatesForMonth(DateTime.Today)
    End Sub

    Private Sub RichTextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles RichTextBox1.KeyPress
        ' Trigger formatting logic for space or Enter key press
        If e.KeyChar = Chr(13) Then ' Chr(13) represents the Enter key
            'AutoReplaceWord()
            FormatTimeRanges()
            e.Handled = False ' Let the character be processed normally
        End If
    End Sub

    Private Sub FormatTimeRanges()
        Dim text As String = RichTextBox1.Text
        ' Extended regex to match time ranges like "9am-2pm", "730am-5pm", "1245am-434pm"
        Dim regex As New Regex("(\b\d{1,2})(\d{2})?(am|pm)-(\d{1,2})(\d{2})?(am|pm)\b", RegexOptions.IgnoreCase)
        Dim matches As MatchCollection = regex.Matches(text)

        For i As Integer = matches.Count - 1 To 0 Step -1
            Dim match As Match = matches(i)
            Dim startHour As String = match.Groups(1).Value
            Dim startMinute As String = If(match.Groups(2).Success, match.Groups(2).Value, "00")
            Dim startAmPm As String = match.Groups(3).Value.ToUpper()

            Dim endHour As String = match.Groups(4).Value
            Dim endMinute As String = If(match.Groups(5).Success, match.Groups(5).Value, "00")
            Dim endAmPm As String = match.Groups(6).Value.ToUpper()

            ' Adjust formatting to not display the leading zero for single-digit hours
            Dim formattedStartHour As String = If(startHour.Length = 1, $"{Integer.Parse(startHour)}", $"{Integer.Parse(startHour):00}")
            Dim formattedEndHour As String = If(endHour.Length = 1, $"{Integer.Parse(endHour)}", $"{Integer.Parse(endHour):00}")

            ' Construct the formatted time range
            Dim replacement As String = $"{formattedStartHour}:{startMinute} {startAmPm} - {formattedEndHour}:{endMinute} {endAmPm}"

            ' Replace the text in the RichTextBox
            RichTextBox1.Select(match.Index, match.Length)
            RichTextBox1.SelectedText = replacement
        Next

    End Sub

    Private Sub SaveTimer_Tick(sender As Object, e As EventArgs)
        ' Save the notes when the Timer elapses and stop the Timer
        SaveNotesForDate(MonthCalendar1.SelectionStart)
        SaveTimer.Stop()
    End Sub

    Private Sub UpdateBoldedDatesForMonth(ByVal dateInMonth As Date)
        Dim notesDirectory As String = GetEventsFolderPath()
        MonthCalendar1.RemoveAllBoldedDates()

        ' Determine the start and end of the month
        Dim firstDayOfMonth As New Date(dateInMonth.Year, dateInMonth.Month, 1)
        Dim lastDayOfMonth As Date = firstDayOfMonth.AddMonths(1).AddDays(-1)

        Dim currentDay As Date = firstDayOfMonth
        While currentDay <= lastDayOfMonth
            Dim filePath As String = Path.Combine(notesDirectory, $"{currentDay:yyyy-MM-dd}.rtf")
            If File.Exists(filePath) Then
                MonthCalendar1.AddBoldedDate(currentDay)
            End If
            currentDay = currentDay.AddDays(1)
        End While

        MonthCalendar1.UpdateBoldedDates()
    End Sub

    Private Sub MonthCalendar1_DateSelected(sender As Object, e As DateRangeEventArgs) Handles MonthCalendar1.DateSelected
        RichTextBox1.Clear()
        UpdateBoldedDatesForMonth(e.Start)
        LoadNotesForDate(e.Start)
    End Sub

    Private Function GetEventsFolderPath() As String
        Dim eventsFolderPath As String = Path.Combine(Application.StartupPath, "Events")
        If Not Directory.Exists(eventsFolderPath) Then
            Directory.CreateDirectory(eventsFolderPath)
        End If
        Return eventsFolderPath
    End Function

    Private Function GetFilePath(selectedDate As Date) As String
        Dim eventsFolderPath As String = GetEventsFolderPath()
        Return Path.Combine(eventsFolderPath, $"{selectedDate.ToString("yyyy-MM-dd")}.rtf")
    End Function

    Private Sub LoadNotesForDate(selectedDate As Date)
        Dim filePath As String = GetFilePath(selectedDate)

        Try
            If File.Exists(filePath) Then
                RichTextBox1.LoadFile(filePath, RichTextBoxStreamType.RichText)
                ' Check if the content is empty after loading and delete the file if so
                If String.IsNullOrWhiteSpace(RichTextBox1.Text) Then
                    File.Delete(filePath) ' Delete the file if it's effectively empty
                End If
            Else
                RichTextBox1.Clear()
            End If
        Catch
            ' Exception caught, but do nothing
        End Try
    End Sub

    Private Sub SaveNotesForDate(selectedDate As Date)
        Dim filePath As String = GetFilePath(selectedDate)
        Dim content As String = RichTextBox1.Text.Trim()

        If String.IsNullOrEmpty(content) Then
            ' If the content is empty or only spaces, delete the file if it exists
            If File.Exists(filePath) Then
                File.Delete(filePath)
            End If
        Else
            ' If there's content, save the file
            RichTextBox1.SaveFile(filePath, RichTextBoxStreamType.RichText)
        End If
    End Sub


    Dim gmailSubMenuItem As ToolStripMenuItem
    Dim outlookSubMenuItem As ToolStripMenuItem
    Dim disableSubMenuItem As ToolStripMenuItem

    Private Function CreateRichTextBoxContextMenu() As ContextMenuStrip
        Dim contextMenu As New ContextMenuStrip()

        ' Add menu items
        ' Dim boldMenuItem As New ToolStripMenuItem("Bold")
        ' AddHandler boldMenuItem.Click, AddressOf BoldToolStripMenuItem_Click
        ' boldMenuItem.Font = New Font(boldMenuItem.Font, FontStyle.Bold) ' Apply bold font style to the menu item
        ' contextMenu.Items.Add(boldMenuItem)

        Dim underlineMenuItem As New ToolStripMenuItem("Underline")
        AddHandler underlineMenuItem.Click, AddressOf UnderlineToolStripMenuItem_Click
        underlineMenuItem.Font = New Font(underlineMenuItem.Font, FontStyle.Underline) ' Apply underline font style to the menu item
        contextMenu.Items.Add(underlineMenuItem)

        Dim italicMenuItem As New ToolStripMenuItem("Italic")
        AddHandler italicMenuItem.Click, AddressOf ItalicToolStripMenuItem_Click
        italicMenuItem.Font = New Font(italicMenuItem.Font, FontStyle.Italic) ' Apply italic font style to the menu item
        contextMenu.Items.Add(italicMenuItem)

        Dim strikeoutMenuItem As New ToolStripMenuItem("Strikeout")
        AddHandler strikeoutMenuItem.Click, AddressOf StrikeoutToolStripMenuItem_Click
        strikeoutMenuItem.Font = New Font(strikeoutMenuItem.Font, FontStyle.Strikeout) ' Apply strikeout font style to the menu item
        contextMenu.Items.Add(strikeoutMenuItem)

        contextMenu.Items.Add(New ToolStripSeparator())

        Dim cutMenuItem As New ToolStripMenuItem("Cut")
        AddHandler cutMenuItem.Click, AddressOf CutToolStripMenuItem_Click
        contextMenu.Items.Add(cutMenuItem)

        Dim copyMenuItem As New ToolStripMenuItem("Copy")
        AddHandler copyMenuItem.Click, AddressOf CopyToolStripMenuItem_Click
        contextMenu.Items.Add(copyMenuItem)

        Dim pasteMenuItem As New ToolStripMenuItem("Paste")
        AddHandler pasteMenuItem.Click, AddressOf PasteToolStripMenuItem_Click
        contextMenu.Items.Add(pasteMenuItem)

        contextMenu.Items.Add(New ToolStripSeparator())

        Dim undoMenuItem As New ToolStripMenuItem("Undo")
        AddHandler undoMenuItem.Click, AddressOf UndoToolStripMenuItem_Click
        contextMenu.Items.Add(undoMenuItem)

        Dim selectAllMenuItem As New ToolStripMenuItem("Select All")
        AddHandler selectAllMenuItem.Click, AddressOf SelectAllToolStripMenuItem_Click
        contextMenu.Items.Add(selectAllMenuItem)

        ' Add "Email Alerts" menu item with submenus
        Dim emailAlertsMenuItem As New ToolStripMenuItem("Email Alerts")
        gmailSubMenuItem = New ToolStripMenuItem("Gmail")
        outlookSubMenuItem = New ToolStripMenuItem("Outlook")
        disableSubMenuItem = New ToolStripMenuItem("Disable")

        ' Add event handlers for the submenus
        AddHandler gmailSubMenuItem.Click, AddressOf GmailToolStripMenuItem_Click
        AddHandler outlookSubMenuItem.Click, AddressOf OutlookToolStripMenuItem_Click
        AddHandler disableSubMenuItem.Click, AddressOf DisableToolStripMenuItem_Click

        ' Add submenus to the "Email Alerts" menu item
        ' emailAlertsMenuItem.DropDownItems.Add(gmailSubMenuItem)
        emailAlertsMenuItem.DropDownItems.Add(outlookSubMenuItem)
        emailAlertsMenuItem.DropDownItems.Add(disableSubMenuItem)

        ' Add "Email Alerts" menu item to the context menu
        contextMenu.Items.Add(emailAlertsMenuItem)

        Return contextMenu
    End Function

    Private Sub GmailToolStripMenuItem_Click(sender As Object, e As EventArgs)
        ' Prompt the user for SMTP credentials
        ' Dim smtpEmail As String = InputBox("Enter Gmail Account (example@gmail.com):", "SMTP Credentials")
        ' Dim smtpPassword As String = InputBox("Enter Password:", "SMTP Credentials")

        ' Save SMTP credentials into My.Settings
        '  My.Settings.Server = "smtp.gmail.com"
        ' My.Settings.Email = smtpEmail
        ' My.Settings.Password = smtpPassword
        ' My.Settings.Alerts = "On"
        ' My.Settings.Save()

        ' Show a checkmark in the Gmail submenu and clear the other checkmarks
        ' gmailSubMenuItem.Checked = True
        ' outlookSubMenuItem.Checked = False
        ' disableSubMenuItem.Checked = False

        'SendTestEmail()

        'MessageBox.Show("Check the test email. The program will send an email alert at 8:00 AM if an event is scheduled.")

        MessageBox.Show("Gmail is no longer supported.")
    End Sub

    Private Sub OutlookToolStripMenuItem_Click(sender As Object, e As EventArgs)
        ' Prompt the user for SMTP credentials
        Dim smtpEmail As String = InputBox("Enter Outlook Email (example@outlook.com):", "SMTP Credentials")
        Dim smtpPassword As String = InputBox("Enter Password:", "SMTP Credentials")

        ' Save SMTP credentials into My.Settings
        My.Settings.Server = "smtp-mail.outlook.com"
        My.Settings.Email = smtpEmail
        My.Settings.Password = smtpPassword
        My.Settings.Alerts = "On"
        My.Settings.Save()

        ' Show a checkmark in the Outlook submenu and clear the other checkmarks
        gmailSubMenuItem.Checked = False
        outlookSubMenuItem.Checked = True
        disableSubMenuItem.Checked = False

        SendTestEmail()

        MessageBox.Show("Check the test email. The program will send an email alert at 8:00 AM if an event is scheduled.")
    End Sub

    Private Sub DisableToolStripMenuItem_Click(sender As Object, e As EventArgs)
        My.Settings.Alerts = "Off"
        My.Settings.Save()

        ' Show a checkmark in the Disable submenu and clear the other checkmarks
        gmailSubMenuItem.Checked = False
        outlookSubMenuItem.Checked = False
        disableSubMenuItem.Checked = True

        MessageBox.Show("Email alerts have been disabled. Choose an account to enable.")
    End Sub

    Private Sub SendEmail()

        ' Check if email alerts are turned off
        If My.Settings.Alerts = "Off" Then
            Return ' Exit the subroutine
        End If

        Dim smtpServer As String = My.Settings.Server
        Dim port As Integer = 587
        Dim emailAddress As String = My.Settings.Email
        Dim password As String = My.Settings.Password

        Dim smtpClient As New SmtpClient(smtpServer)
        smtpClient.Port = port
        smtpClient.EnableSsl = True
        smtpClient.Credentials = New System.Net.NetworkCredential(emailAddress, password)

        ' Optionally, set additional properties such as timeout
        smtpClient.Timeout = 10000 ' 10 seconds

        ' Now you can use smtpClient to send emails
        Dim mail As New MailMessage()
        mail.From = New MailAddress(emailAddress)
        mail.To.Add(emailAddress)
        mail.Subject = "Today's Calendar Events"

        Dim rtfFilePath As String = GetFilePath(DateTime.Today)
        If File.Exists(rtfFilePath) Then
            ' Load the RTF content into a RichTextBox
            Dim rtBox As New RichTextBox()
            rtBox.LoadFile(rtfFilePath, RichTextBoxStreamType.RichText)

            ' Extract the plain text from the RichTextBox
            mail.Body = rtBox.Text
        Else
            Return
        End If

        Try
            smtpClient.Send(mail)
        Catch ex As Exception
            MessageBox.Show($"Failed to send email: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ' Dispose of the SmtpClient to release resources
            smtpClient.Dispose()
        End Try
    End Sub

    Private Sub SendTestEmail()

        ' Check if email alerts are turned off
        If My.Settings.Alerts = "Off" Then
            Return ' Exit the subroutine
        End If

        Dim smtpServer As String = My.Settings.Server
        Dim port As Integer = 587
        Dim emailAddress As String = My.Settings.Email
        Dim password As String = My.Settings.Password

        Dim smtpClient As New SmtpClient(smtpServer)
        smtpClient.Port = port
        smtpClient.EnableSsl = True
        smtpClient.Credentials = New System.Net.NetworkCredential(emailAddress, password)

        ' Optionally, set additional properties such as timeout
        smtpClient.Timeout = 8000 ' 8 seconds

        ' Now you can use smtpClient to send emails
        Dim mail As New MailMessage()
        mail.From = New MailAddress(emailAddress)
        mail.To.Add(emailAddress)
        mail.Subject = "Test Email Alert"
        mail.Body = "Success"

        Try
            smtpClient.Send(mail)
        Catch ex As Exception
            MessageBox.Show($"Failed to send email: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ' Dispose of the SmtpClient to release resources
            smtpClient.Dispose()
        End Try
    End Sub

    ' Subroutines for context menu options
    'Private Sub BoldToolStripMenuItem_Click(sender As Object, e As EventArgs)
    '    RichTextBox1.SelectionFont = New Font(RichTextBox1.Font, RichTextBox1.SelectionFont.Style Xor FontStyle.Bold)
    ' End Sub

    Private Sub UnderlineToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RichTextBox1.SelectionFont = New Font(RichTextBox1.Font, RichTextBox1.SelectionFont.Style Xor FontStyle.Underline)
    End Sub

    Private Sub ItalicToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RichTextBox1.SelectionFont = New Font(RichTextBox1.Font, RichTextBox1.SelectionFont.Style Xor FontStyle.Italic)
    End Sub

    Private Sub StrikeoutToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RichTextBox1.SelectionFont = New Font(RichTextBox1.Font, RichTextBox1.SelectionFont.Style Xor FontStyle.Strikeout)
    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RichTextBox1.Cut()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RichTextBox1.Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RichTextBox1.Paste()
    End Sub

    Private Sub UndoToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RichTextBox1.Undo()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(sender As Object, e As EventArgs)
        RichTextBox1.SelectAll()
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If e.CloseReason = CloseReason.UserClosing Then
            ' Minimize to system tray instead of closing
            Me.Hide()
            Me.WindowState = FormWindowState.Minimized
            e.Cancel = True
        End If
    End Sub

    Private Sub TrayIcon_MouseClick(sender As Object, e As MouseEventArgs) Handles TrayIcon.MouseClick
        ' Check if the left mouse button is clicked
        If e.Button = MouseButtons.Left Then
            If Me.WindowState = FormWindowState.Normal Then
                ' If the form is currently shown, minimize it
                Me.Hide()
                Me.WindowState = FormWindowState.Normal
                Me.WindowState = FormWindowState.Minimized
            Else
                ' Otherwise, restore the form
                Me.Hide()
                Me.WindowState = FormWindowState.Normal
                Me.Show()
            End If
        End If
    End Sub

    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        ' Minimize to system tray when form is minimized
        If Me.WindowState = FormWindowState.Minimized Then
            Me.Hide()
            TrayIcon.Visible = True
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs)
        ' Clean up resources and exit the application
        TrayIcon.Dispose()
        Application.Exit()
    End Sub

End Class
